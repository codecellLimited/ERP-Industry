<?php $__env->startSection('page_title', 'Transection Form'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add New Transection</h1>
        <a href="<?php echo e(route('transection')); ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back
        </a>
    </div>


   <div class="row" style="color:black;">
        <div class="col-12">
            <div class="card shadow">

                <div class="card-body">
                    <?php if(isset($transection)): ?>
                    <form action="<?php echo e(route('transection.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php else: ?>
                    <form action="<?php echo e(route('transection.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <?php if(isset($transection)): ?>
                        <input type="hidden" name="key" value="<?php echo e($transection->id); ?>">
                        <?php endif; ?>

                            

                        <div class="form-group">
                            <div class="row">

                                <div class="col-md">
                                    <label for=""><b>Date</b></label>
                                    <input type="date" name="date" 
                                        class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($transection)): ?>
                                        value="<?php echo e((empty($transection->date) ? date('Y-m-d',strtotime(today())) : date('Y-m-d', strtotime($transection->date)))); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('date')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Transection For</b></label>
                                    <select name="purpose" id="" onchange="toggoldiv(this.value)" class="form-control <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="" selected disabled>Select One</option>
                                        <option value="1" <?php if(isset($transection)): ?> <?php if($transection->purpose == 1): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >Party Receive </option>
                                        <option value="2" <?php if(isset($transection)): ?> <?php if($transection->purpose == 2): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >Supplier Payment</option>
                                    </select>

                                    <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md" style="display:none;" id="party_show">
                                    <label for=""><b>Party Name</b></label>
                                    <select name="party_id"  class="form-control <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = \App\Models\Party::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                        <?php if(isset($transection)): ?>
                                        <?php echo e(($transection->party_id == $item->id) ? 'selected':''); ?>

                                        <?php else: ?><?php echo e((old('party_id')== $item->id) ? 'selected' : ''); ?>

                                        <?php endif; ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                    <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md" style="display:none;" id="supplier_show" >
                                    <label for=""><b>Supplier Company Name</b></label>
                                    <select name="supplier_id" class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = \App\Models\Supplier::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                        <?php if(isset($transection)): ?>
                                        <?php echo e(($transection->supplier_id == $item->id) ? 'selected':''); ?>

                                        
                                        <?php else: ?><?php echo e((old('supplier_id')== $item->id) ? 'selected' : ''); ?>

                                        
                                        <?php endif; ?>>
                                        
                                        <?php echo e($item->company); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                    <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                  
                            </div>
                        </div>



                        <div class="form-group">
                            <div class="row">

                            <div class="col-md">
                                    <label for=""><b>Order No</b></label>
                                    <input type="text" name="order_id" onchange="loadtotaldue()" id="order_id"
                                        class="form-control <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($transection)): ?>
                                        value="<?php echo e($transection->order_id); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('order_id')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Total Due</b></label>
                                    <input type="text" name="due" id="order_no"
                                        class="form-control <?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($transection)): ?>
                                        value="<?php echo e($transection->due); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('due')); ?>"
                                        <?php endif; ?> readonly>

                                    <?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md" >
                                    <label for=""><b>Payment Method</b></label>
                                    <select name="payment_method" id="" onchange="transection(this.value)" class="form-control <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="" selected disabled>Select One</option>
                                        <option value="1" <?php if(isset($transection)): ?> <?php if($transection->payment_method == 1): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >Hand cash</option>
                                        <option value="2" <?php if(isset($transection)): ?> <?php if($transection->payment_method == 2): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >Bank Payment</option>
                                    </select>

                                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="col-md" style="display:none;" id="account">
                                    <label for=""><b>Account</b></label>
                                    <select name="account" id="" class="form-control <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = \App\Models\Bankadd::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" 
                                            <?php if(isset($transection)): ?>
                                            <?php echo e(($transection->account == $item->id)? 'selected':''); ?>

                                            <?php else: ?><?php echo e((old('account')== $item->id) ? 'selected' : ''); ?>


                                            <?php endif; ?>> 
                                       
                                        <?php echo e($item->account_number); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                    <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md" style="display:none;" id="bearer">
                                    <label for=""><b>Bearer Name</b></label>
                                    <input type="text" name="bearer" 
                                        class="form-control <?php $__errorArgs = ['bearer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($transection)): ?>
                                        value="<?php echo e($transection->bearer); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('bearer')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['bearer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Amount</b></label>
                                    <input type="text" name="amount" 
                                        class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($transection)): ?>
                                        value="<?php echo e($transection->amount); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('amount')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
  
                            </div>
                        </div>


                        <div class="form-group">
                            
                                
                                <div class="cal-md">
                                    <label for=""><b>Remark/ Note</b></label>
                                    <textarea type="text" name="remark" class="form-control <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php if(isset($transection)): ?><?php echo e($transection->remark); ?><?php else: ?> <?php echo e(old('remark')); ?><?php endif; ?></textarea>

                                    <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                            
                        </div>


                        


                        <button class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
   </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        



        function toggoldiv(value){
            
            const party_show = document.getElementById("party_show");
            const supplier_show = document.getElementById("supplier_show");

            if(value == '1'){
                party_show.style.display = "block";
                supplier_show.style.display = "none";

                const loadtotaldue = () => {
                    const key = $("#order_id").val();

                    $.ajax({
                        url: '<?php echo e(route("order.due")); ?>',
                        type: 'GET',
                        data:{
                            key: key
                        },
                        success: (res) => {
                            console.log(res);
                            $("#order_no").val(res);
                        },
                        error: (err) => {
                            console.log(err);
                        }
                    })
                }

            }  
            else if(value == '2'){
                
                party_show.style.display = "none";
                supplier_show.style.display = "block";

                const loadtotaldue = () => {
                    const key = $("#order_id").val();

                    $.ajax({
                        url: '<?php echo e(route("purchase.due")); ?>',
                        type: 'GET',
                        data:{
                            key: key
                        },
                        success: (res) => {
                            console.log(res);
                            $("#order_no").val(res);
                        },
                        error: (err) => {
                            console.log(err);
                        }
                    })
                }

            }
        }

        function transection(value){
            const bearer = document.getElementById("bearer");
            const account = document.getElementById("account");

            if(value == '1'){
                bearer.style.display = "block";
                account.style.display = "none";
            }  
            else if(value == '2'){
                
                bearer.style.display = "none";
                account.style.display = "block";
            }
        }
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/account/bankcash/transection/form.blade.php ENDPATH**/ ?>