<?php $__env->startSection('page_title', 'Employees on leave'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Leave Application List</h1>
        <a href="<?php echo e(route('leave.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Add new Leave Application
        </a>
    </div>

    <div class="card shadow">
        <div class="card-body table-responsive">
            <table class="table table-striped table-hover data-table">
            <?php $__env->startSection('page_title', 'Employee List on Leave'); ?>
                <thead>
                    <tr style="color:black;">
                        <th scope="col">#</th>
                        <th scope="col">Employee ID</th>
                        <th scope="col">Employee Name</th>
                        <th scope="col">Leave Type</th>
                        <th scope="col">Date From Leave</th>
                        <th scope="col">Next Joining Date</th>
                        <th scope="col">Total Days</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="color:black;">
                        <th scope="row" ><?php echo e(++$key); ?></th>
                        <td><?php echo e(Str::upper($item->employee_id)); ?></td>
                        <td><?php echo e(Str::upper($item->name)); ?></td>

                        <td><?php if( $item->type == 1): ?> Inform
                            <?php elseif( $item->type == 2): ?> Application
                            <?php elseif( $item->type == 3): ?> No Pay
                            <?php elseif( $item->type == 4): ?> None
                            <?php else: ?> 
                            <?php endif; ?></td>
                       
                        <td><?php echo e(date("d-m-Y", strtotime($item->date_from))); ?></td>
                        <td><?php echo e(date("d-m-Y", strtotime($item->date_to))); ?></td>
                        
                        <td><?php echo e($item->total_days); ?></td>
                        <td class="text-nowrap">
                             <a href="<?php echo e(route('leave.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-pen"></i>
                            </a>

                            <button class="btn btn-sm btn-primary"
                                onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('leave/delete/<?php echo e($item->id); ?>'); }">
                                <i class="fas fa-trash"></i>
                            </button> 
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 py-5 text-center">
                        <h4 class="text-muted"><b>No Leave Application in  List</b></h4>
                    </div>
                    <?php endif; ?>
                    
                </tbody>
            </table>
        </div>
    </div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/HR/leave/table.blade.php ENDPATH**/ ?>