<?php $__env->startSection('page_title', 'Bank Accounts'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Bank Accounts</h1>
        <a href="<?php echo e(route('bankadd.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Add a Bank Account
        </a>
    </div>


   <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $bankadd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="card">
                <div class="card-body" style="color:black;">
                    <div class="my-3 text-center">
                        <h6><b>Bank Name: </b><br><?php echo e(\App\Models\Bank::find($item->id)->name); ?></h6>
                        <h6><b>Branch: </b><br><?php echo e($item->branch); ?></h6>
                        <h6><b>Account Holder: </b><br><?php echo e($item->account_holder); ?></h6>
                        <h6><b>Account Type: </b><br><?php echo e($item->account_type); ?></h6>
                        <h6><b>Account Number: </b><br><?php echo e($item->account_number); ?></h6>

                        <a href="<?php echo e(route('bankadd.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-pen"></i>
                        </a>

                        <button class="btn btn-sm btn-primary"
                        onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('bankadd/delete/<?php echo e($item->id); ?>'); }">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 py-5 text-center">
            <h4 class="text-muted"><b>No Supplier Yet</b></h4>
        </div>
        <?php endif; ?>
   </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/account/financial/bankadd/table.blade.php ENDPATH**/ ?>