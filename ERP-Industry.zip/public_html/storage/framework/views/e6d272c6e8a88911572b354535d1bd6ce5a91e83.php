<?php $__env->startSection('web-content'); ?>
<?php $__env->startSection('page_title', 'profile'); ?>
<!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Supplier Profile</h1>
        <a href="<?php echo e(route('suppliers')); ?>" class="btn btn-primary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back
        </a>
    </div>

<!-- profile -->
    <div class="modal-content">

        <div class="modal-body" style="color:black;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <h4><b> Supplier Name :</b> <?php echo e($Suppliers->name); ?></h4>
                        <h4><b> Supplier Phone:</b> <?php echo e($Suppliers->phone); ?></h4>
                        <h4><b> Supplier Email:</b> <?php echo e($Suppliers->email); ?></h4>
                        <h4><b> Company Name:</b> <?php echo e($Suppliers->company); ?></h4>
                    </div>
                <div class="col-md-4 ml-auto">
                    <img src="<?php echo e(asset($Suppliers->image)); ?>" alt=""  class="img-fluid" style="width:200px;height:200px;">
                </div>
            </div>
            <div class="card shadow">
                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover data-table" style="color:black;">
                    
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Purchase NO</th>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Discount(%)</th>
                                <th>Sub Total</th>
                                <th>Transport Cost</th>
                                <th>Total</th>
                                <th>Total Paid</th>
                                <th>Due</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row" ><?php echo e(++$key); ?></th>
                                <td><?php echo e($item->id); ?></td>
                                <td>
                                    <?php $abc = json_decode($item->data);?>
                                    <table>
                                    <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e(\App\Models\Material::find($row->name)->name); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </td>
                                <td>
                                    
                                    <table>
                                        <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->quantity); ?> <?php echo e(\App\Models\Unit::find($row->unit)->name); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </td>
                                <td>
                                    
                                    <table>
                                        <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->unit_price); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </td>
                                <td>
                                    
                                    <table>
                                        <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->discount); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </td>
                                <td>
                                    
                                    <table>
                                        <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->sub_total); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </td>
                                <td><?php echo e($item->transport_cost); ?></td>
                                <td><?php echo e($item->total_price); ?></td>
                                <td><?php echo e($item->total_paid); ?></td>
                                <td><?php echo e($item->due); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 py-5 text-center">
                                <tr>
                                    <td colspan='11'>No Record Found</td>
                                </tr>
                            </div>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>

            </div>

        </div>
    </div>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/supplier/supplier/profile.blade.php ENDPATH**/ ?>