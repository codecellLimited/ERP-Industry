<?php $__env->startSection('page_title', 'Parties'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Party Profile</h1>
        <a href="<?php echo e(route('party.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Create Party
        </a>
    </div>


   <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="card">
                <div class="card-body" style="color:black;">
                    <div class="my-3 text-center">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid rounded-circle m-auto d-block" style="width:100px; height:100px;">
                        <br>
                        <h5><b><?php echo e($item->company); ?></b></h5>
                        <h6><?php echo e($item->email); ?></h6>
                        <h6><?php echo e($item->phone); ?></h6>
                        <a href="<?php echo e(route('party.profile', $item->id)); ?>" class="btn btn-sm btn-primary">
                        <i class="fa fa-eye" aria-hidden="true"></i> </a>
                        
                        <a href="<?php echo e(route('party.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-pen"></i>
                        </a>

                        <button class="btn btn-sm btn-primary"
                        onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('party/delete/<?php echo e($item->id); ?>'); }">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
            <br>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 py-5 text-center">
            <h4 class="text-muted"><b>No Party Yet</b></h4>
        </div>
        <?php endif; ?>
   </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/party/party/table.blade.php ENDPATH**/ ?>