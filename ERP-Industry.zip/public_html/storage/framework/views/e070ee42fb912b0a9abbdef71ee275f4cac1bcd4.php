<?php $__env->startSection('page_title', 'Production Per Order'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Production Per Order</h1>
        
    </div>


        

   <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $orderid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="card shadow">
                <div class="card-body" style="color:black;">
                    <div class="my-3 text-center">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid  m-auto d-block" style="width: 150px; height:100px;">
                        <br>
                        <h6><b>Order Name: </b><?php echo e(\App\Models\Product::find($item->product_id)->name); ?></h6>
                        <h6><b>Party Name: </b><?php echo e(\App\Models\Party::find($item->party_id)->name); ?></h6>
                        <h6><b>Total Order: </b><?php echo e($item->quantity); ?></h6>
                            
                
                        <h6><b>Total Production: </b><?php echo e(\App\Models\ProductionPerDay:: where('order_id', $item->id)->sum('production')); ?></h6>
                        
                        <h6><b>Production Left: </b><?php echo e($item->quantity - \App\Models\ProductionPerDay:: where('order_id', $item->id)->sum('production')); ?></h6>

                        <button class="btn btn-sm btn-primary"
                        onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('ProductionPerParty/delete/<?php echo e($item->id); ?>'); }">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 py-5 text-center">
            <h4 class="text-muted"><b>No Record Yet</b></h4>
        </div>
        <?php endif; ?>
   </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/inventory/ProductionPerParty/table.blade.php ENDPATH**/ ?>