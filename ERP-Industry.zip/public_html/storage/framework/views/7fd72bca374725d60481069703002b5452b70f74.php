<?php $__env->startSection('page_title', 'Sanction list'); ?>
   
<?php $__env->startSection('web-content'); ?>

<!-- page heading  -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="mb-0 text-gray-800 "> Sanction List</h1>
    <a href="<?php echo e(route('sanction.create')); ?>" class="btn btn-primary shadow-sm">
        <i class="fas fa-plus fa-sm text-white-50"></i>
        <span>Add new Record</span>
    </a>

</div>

<!-- page contain  -->
<div class="card shadow">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover data-table-print" style="color:black;">
        <?php $__env->startSection('page_title', 'Sanction list from sales'); ?>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Sanction Date</th>
                    <th>Purpose</th>
                    <th>Amount</th>
                    <th>Remark</th>
                    <th>Status</th>
                    <th>Action</th>

                </tr>
            </thead>

            
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sanction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row" ><?php echo e(++$key); ?></th>
                    <th><?php echo e($item->sanction_date); ?></th>
                    <td><?php echo e($item->purpose); ?></td>
                    <td><?php echo e($item->amount); ?></td>
                    <td><?php echo e($item->sanction_note); ?></td>
                    <td>
                        <?php if($item->status == 1): ?>
                        <span class="badge bg-warning">Stand by</span>
                        <?php elseif($item->status == 2): ?>
                        <span class="badge bg-success text-light">Send</span>
                        <?php elseif($item->status == 3): ?>
                        <span class="badge bg-primary text-light">Accepted</span>
                        <?php elseif($item->status == 0): ?>
                        <span class="badge bg-danger text-light">Rejected</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-inline-block dropdown">
                            <button type="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false" class="dropdown-toggle btn btn-sm btn-info text-nowrap">
                                Action
                            </button>
                            <div tabindex="-1" role="menu" aria-hidden="true"
                                class="dropdown-menu dropdown-menu-right">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('sanction.edit', $item->id)); ?>">
                                            <i class="nav-link-icon fa fa-pen"></i>
                                            <span> Edit</span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::" onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('sanction/delete/<?php echo e($item->id); ?>'); }">
                                            <i class="nav-link-icon fa fa-trash"></i>
                                            <span> Delete</span>
                                        </a>
                                    </li>

                                    <?php if($item->status !== 1 && $item-> status != 3 && $item-> status != 0): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('sanction.status', [$item->id, 1])); ?>'); }"
                                        >
                                            <i class="nav-link-icon fa fa-handshake"></i>
                                            <span>Stand by</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    
                                    <?php if($item->status !== 2 && $item-> status != 3): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('sanction.status', [$item->id, 2])); ?>'); }"
                                        >
                                            <i class="nav-link-icon fa fa-handshake"></i>
                                            <span>Send</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                    
                                </ul>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-6 text-center">
                    <tr>
                        <td colspan="6" style="text-align: center;">No record found</td>
                    </tr>
                </div>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('.data-table-print').DataTable( {
                dom: 'Bfrtip',
                ordering: false,
                buttons: [
                    {
                        extend: 'print',
                        exportOptions: {
                            stripHtml : false,
                            columns: [1, 2, 3, 4, 5] 
                            //specify which column you want to print
    
                        }
                    },
                    'excel', 'pdf',
                ]
            } );
        } );
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/sales/sanction_payment/table.blade.php ENDPATH**/ ?>