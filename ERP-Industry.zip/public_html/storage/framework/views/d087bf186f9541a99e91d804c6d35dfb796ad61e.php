<?php $__env->startSection('page_title', 'Sanction Account'); ?>
   
<?php $__env->startSection('web-content'); ?>

<!-- page heading  -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="mb-0 text-gray-800 "> Sanction List from accounts</h1>
    

</div>

<!-- page contain  -->
<div class="card shadow">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover data-table" style="color:black;">
        <?php $__env->startSection('page_title', 'Sanctioned list from Accounce'); ?>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Sanction Date</th>
                    <th>Purpose</th>
                    <th>Amount</th>
                    <th>Remark</th>
                    <th>Status</th>
                    <th>Action</th>

                </tr>
            </thead>

            
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sanction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row" ><?php echo e(++$key); ?></th>
                    <th><?php echo e($item->sanction_date); ?></th>
                    <td><?php echo e($item->purpose); ?></td>
                    <td><?php echo e($item->amount); ?></td>
                    <td><?php echo e($item->sanction_note); ?></td>
                    <td>
                        <?php if($item->status == 2): ?>
                        <span class="badge bg-warning">Stand by</span>
                        <?php elseif($item->status == 3): ?>
                        <span class="badge bg-primary text-light">Accept</span>
                        <?php elseif($item->status == 0): ?>
                        <span class="badge bg-danger text-light">Rejected</span>
                        <?php endif; ?>
                        
                    </td>
                    <td>
                        <div class="d-inline-block dropdown">
                            <button type="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false" class="dropdown-toggle btn btn-sm btn-info text-nowrap">
                                Action
                            </button>
                            <div tabindex="-1" role="menu" aria-hidden="true"
                                class="dropdown-menu dropdown-menu-right">
                                <ul class="nav flex-column">
                            
                                    
                                    
                                    <?php if($item->status !== 3): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('sanction.status', [$item->id, 3])); ?>'); }"
                                        >
                                            <i class="nav-link-icon fa fa-handshake"></i>
                                            <span>Accepted</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($item->status !== 0): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('sanction.status', [$item->id, 0])); ?>'); }"
                                        >
                                            <i class="nav-link-icon fa fa-handshake"></i>
                                            <span>Rejected</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                    
                                </ul>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-6 text-center">
                    <tr>
                        <td colspan="6" style="text-align: center;">No record found</td>
                    </tr>
                </div>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/account/sanction_payment/table.blade.php ENDPATH**/ ?>