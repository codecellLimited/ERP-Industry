<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add a New Brand</h1>
        <a href="<?php echo e(route('Brand')); ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back
        </a>
    </div>


   <div class="row">
        <div class="col-12">
            <div class="card shadow">

                <div class="card-body">
                    <?php if(isset($Brand)): ?>
                    <form action="<?php echo e(route('Brand.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php else: ?>
                    <form action="<?php echo e(route('Brand.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <?php if(isset($Brand)): ?>
                        <input type="hidden" name="key" value="<?php echo e($Brand->id); ?>">
                        <?php endif; ?>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md">
                                    <label for="">Brand Name</label>
                                    <input type="text" name="name" autofocus
                                        class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($Brand)): ?>
                                        value="<?php echo e($Brand->name); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('name')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for="">Brand Discription</label>
                                    <input type="text" name="description" autofocus
                                        class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($Brand)): ?>
                                        value="<?php echo e($Brand->description); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('description')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                            </div>
                            
                        </div>

                            
                            
                        
                            <div class="form-group">
                                <div class="col-md-4">
                                <label for=""><b>Brand Image</b></label>
                                <br>
                                <?php if(isset($Brand)): ?>
                                    <img src="<?php echo e(asset($Brand->image)); ?>" alt=""weight="100px" height="100px">
                                <?php endif; ?>    
                                <input type="file" name="image" 
                                    class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        

                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                                



                        <button class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
   </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/sales/brand/form.blade.php ENDPATH**/ ?>