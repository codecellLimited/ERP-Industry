<?php $__env->startSection('web-content'); ?>
<?php $__env->startSection('page_title', 'profile'); ?>
<!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Purchase Invoice</h1>
        <button class="btn btn-sm btn-outline-primary" onclick="printDiv('printDiv')">
            <i class="fa fa-print"></i>
            Print
        </button>
        <a href="<?php echo e(route('purchase')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back
        </a>
    </div>

<!-- profile -->
    <div class="modal-content">

        <div class="modal-body py-5" style="color:black;" id="printDiv">
        <br>
            <div class="container-fluid">
                <div class="row mb-5">
                    <div class="col-md-8">
                        <h4><b>Purchase Date: </b> <?php echo e(date('d-m-Y H:i:s A')); ?></h4>
                        <h4><b>Purchase No: </b> <?php echo e($record->id); ?></h4>
                        <h4><b> Supplier Name :</b> <?php echo e($supplier->name); ?></h4>
                        <h4><b> Supplier Phone:</b> <?php echo e($supplier->phone); ?></h4>
                        <h4><b> Supplier Email:</b> <?php echo e($supplier->email); ?></h4>
                        <h4><b> Company Name:</b> <?php echo e($supplier->company); ?></h4>
                    </div>
                <div class="col-md-4 ml-auto">
                    <img src="<?php echo e(asset($supplier->image)); ?>" alt="" style="width:200px;height:200px" class="img-fluid">
                </div>
            </div>
            <div class="card shadow">
                <div class="card-body table-responsive">
                    <table class="table table-striped table-hover" style="color:black;">
                    
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Discount(%)</th>
                                <th>Sub Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $abc = json_decode($record->data);?>

                            <?php $__currentLoopData = $abc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(\App\Models\Material::find($row->name)->name); ?></td>
                                <td><?php echo e($row->quantity); ?> <?php echo e(\App\Models\Unit::find($row->unit)->name); ?> </td>
                                <td><?php echo e($row->unit_price); ?> </td>
                                <td><?php echo e($row->discount); ?> </td>
                                <td><?php echo e($row->sub_total); ?> </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b>Transport Cost :</b></td>
                                <td><?php echo e($record->transport_cost); ?></td>
                            </tr>

                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b>Total Price :</b></td>
                                <td><?php echo e($record->total_price); ?></td>
                            </tr>

                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b>Total Paid :</b></td>
                                <td><?php echo e($record->total_paid); ?></td>
                            </tr>

                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><b>Total Due :</b></td>
                                <td><?php echo e($record->due); ?></td>
                            </tr>
                        </tbody>
                    </table>

                    
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
     <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/supplier/materialPurchase/invoice.blade.php ENDPATH**/ ?>