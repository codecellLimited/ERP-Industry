<?php $__env->startSection('web-content'); ?>
    
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add a new Record</h1>
        <a href="<?php echo e(route('sanction')); ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back
        </a>
    </div>


   <div class="row">
        <div class="col-12">
            <div class="card shadow">

                <div class="card-body card-responsive">
                    <?php if(isset($sanction)): ?>
                    <form action="<?php echo e(route('sanction.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php else: ?>
                    <form action="<?php echo e(route('sanction.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <?php if(isset($sanction)): ?>
                        <input type="hidden" name="key" value="<?php echo e($sanction->id); ?>">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md">
                                    <label for=""><b> Sanction Date *</b></label>
                                    <input type="date" name="sanction_date" 
                                        class="form-control <?php $__errorArgs = ['sanction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($sanction)): ?>
                                        value="<?php echo e(date('Y-m-d', strtotime($sanction->sanction_date ))); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('sanction_date')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['sanction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Purpose *</b></label>
                                    <input type="text" name="purpose" 
                                        class="form-control <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($sanction)): ?>
                                        value="<?php echo e($sanction->purpose); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('purpose')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Amount *</b></label>
                                    <input type="text" name="amount" 
                                        class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($sanction)): ?>
                                        value="<?php echo e($sanction->amount); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('amount')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                            </div>
                        </div>


                        <div class="form-group">
                            <label for=""><b>Sanction Note</b></label>
                            <textarea type="text" name="sanction_note" class="form-control <?php $__errorArgs = ['sanction_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php if(isset($sanction)): ?><?php echo e($sanction->sanction_note); ?>

                             <?php else: ?> <?php echo e(old('sanction_note')); ?><?php endif; ?></textarea>

                            <?php $__errorArgs = ['sanction_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        <button class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
   </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/sales/sanction_payment/form.blade.php ENDPATH**/ ?>