<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <?php if(isset($record)): ?>
                Update record
            <?php else: ?>
                New purchase
            <?php endif; ?>
        </h1>
        <a href="<?php echo e(route('purchase')); ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Back
        </a>
    </div>


   <div class="row">
        <div class="col-12">
            <div class="card shadow">

                <div class="card-body text-dark">
                    <?php if(isset($record)): ?>
                    <form action="<?php echo e(route('purchase.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php else: ?>
                    <form action="<?php echo e(route('purchase.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <?php if(isset($record)): ?>
                        <input type="hidden" name="key" value="<?php echo e($record->id); ?>">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md">
                                    <label for="">Purchase Date*</label>
                                    <input type="date" name="purchase_date" 
                                        class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($record)): ?>
                                        value="<?php echo e(date('Y-m-d', strtotime($record->purchase_date))); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('purchase_date')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for="">Purchase Receive Date</label>
                                    <input type="date" name="purchase_receive_date" 
                                        class="form-control <?php $__errorArgs = ['purchase_receive_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($record)): ?>
                                        value="<?php echo e(date('Y-m-d', strtotime($record->purchase_receive_date))); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('purchase_receive_date')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['purchase_receive_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for="">Suppliers*</label>
                                    <select name="supplier_id" class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php if(isset($record)): ?> <?php echo e(($item->id == $record->supplier_id) ? 'selected' : ''); ?> <?php endif; ?>>
                                            <?php echo e($item->company); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                    <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>


                        <div class="form-group" id="product_item">
                            <?php if(isset($record)): ?>
                                <?php $__currentLoopData = json_decode($record->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="material-row-<?php echo e($key); ?>">
                                    
                                    <div class="col-md">
                                        <label for="">Product name*</label>
                                        <select name="name[]" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="" selected disabled>Select One</option>
                                            <?php $__currentLoopData = \App\Models\Material::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if(isset($records)): ?> <?php echo e(($item->id == $records->name) ? 'selected' : ''); ?> <?php endif; ?>>
                                                <?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>

                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                
                                    

                                    <div class="col-md">
                                        <label for=""><b>Quantity*</b></label>
                                        <input type="text" name="quantity[]" id="quantity-<?php echo e($key); ?>"
                                            class="quantity form-control"
                                            onchange="calculator('<?php echo e($key); ?>')" value="<?php echo e($records->quantity); ?>">
                                    </div>

                                    <div class="col-md">
                                    <label for="">Unit*</label>
                                    <select name="unit[]" id="" class="form-control <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = \App\Models\Unit::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if(isset($records)): ?>
                                                    <?php echo e(($records->unit == $item->id) ? 'selected' : ''); ?>

                                                <?php else: ?><?php echo e((old('unit')== $item->id) ? 'selected' : ''); ?>


                                                <?php endif; ?>> 
                                        
                                            <?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                    <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                    <div class="col-md">
                                        <label for=""><b>Unit Price*</b></label>

                                        <input type="text" name="unit_price[]" id="unit_price-<?php echo e($key); ?>" 
                                            class="unit_price form-control" value="<?php echo e($records->unit_price); ?>"
                                            onchange="calculator('<?php echo e($key); ?>')">
                                    </div>

                                    <div class="col-md">
                                        <label for=""><b>Discount(%)*</b></label>
                                        <input type="text" name="discount[]" id="discount-<?php echo e($key); ?>"
                                            class="discount form-control" value="<?php echo e($records->discount); ?>"
                                            onkeyup="calculator('<?php echo e($key); ?>')">
                                    </div>

                                    <div class="col-md">
                                        <label><b>Sub Total</b></label>
                                        <input type="text" name="sub_total[]" class="form-control" readonly
                                            id="single-total-<?php echo e($key); ?>" value="<?php echo e($records->sub_total); ?>">
                                    </div>

                                    <?php if($key == 0): ?>
                                    <div class="col-md p-2 ">
                                        <div class="btn btn-primary mt-4" id="add_product_item"> <i class="fas fa-plus"></i> </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="col-md p-2 ">
                                        <div class="btn btn-danger mt-4" id="remove_product_item" onclick="deleteRow('<?php echo e($key); ?>')">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div class="row" id="material-row-0">

                                <div class="col-md-3">
                                    <label for="">Product Name*</label>
                                    <select name="name[]" id="productKey-0" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="loadProductUnit('0')">
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = \App\Models\Material::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php if(isset($record)): ?>
                                                <?php echo e(($record->name == $item->id)? 'selected':''); ?>

                                            <?php else: ?><?php echo e((old('name')?'selected':'')); ?>  
                                            <?php endif; ?>  >
                                        <?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            

                                <div class="col-md">
                                    <label for=""><b>Quantity*</b></label>
                                    <input type="text" name="quantity[]" id="quantity-0"
                                        class="quantity form-control"
                                        onchange="calculator('0')">
                                </div>


                                <div class="col-md" id="loadUnitFromAjax-0">
                                    <label for="">Unit*</label>
                                    <select name="unit[]" id="productUnit-0" class="form-control <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                        <option value="" selected disabled>Select One</option>
                                        <?php $__currentLoopData = \App\Models\Unit::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php if(isset($record)): ?>
                                                    <?php echo e(($record->unit_id == $item->id) ? 'selected' : ''); ?>

                                                <?php else: ?><?php echo e((old('unit_id')== $item->id) ? 'selected' : ''); ?>


                                                <?php endif; ?>> 
                                        
                                            <?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                    <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Unit Price*</b></label>

                                    <input type="text" name="unit_price[]" id="unit_price-0" 
                                        class="unit_price form-control"
                                        onchange="calculator('0')">
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Discount(%)*</b></label>
                                    <input type="text" name="discount[]" id="discount-0"
                                        class="discount form-control"
                                        onkeyup="calculator('0')">
                                </div>

                                <div class="col-md">
                                    <label><b>Sub Total</b></label>
                                    <input type="text" name="sub_total[]" class="form-control" id="single-total-0" readonly>
                                </div>

                                <div class="col-md p-2 ">
                                    <div class="btn btn-primary mt-4" id="add_product_item"> <i class="fas fa-plus"></i> </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md">
                                    <label for=""><b>Transport Cost*</b></label>
                                    <input type="text" name="transport_cost" id="transport_cost"
                                        class="form-control <?php $__errorArgs = ['transport_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        onkeyup="totalCount()"
                                        <?php if(isset($record)): ?>
                                        value="<?php echo e($record->transport_cost); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('transport_cost')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['transport_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Total Bill</b></label>
                                    <input type="text" name="total_price" id="total_bill" readonly
                                        class="form-control <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($record)): ?>
                                        value="<?php echo e($record->total_price); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('total_price')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md">
                                    <label for=""><b>Total Paid*</b></label>
                                    <input type="text" name="total_paid" id="total_paid"
                                        class="form-control <?php $__errorArgs = ['total_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        onkeyup="totalCount()"
                                        <?php if(isset($record)): ?>
                                        value="<?php echo e($record->total_paid); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('total_paid')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['total_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="col-md">
                                    <label for=""><b>Due</b></label>
                                    <input type="text" name="due" id="due" readonly
                                        class="form-control <?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        <?php if(isset($record)): ?>
                                        value="<?php echo e($record->due); ?>"
                                        <?php else: ?>
                                        value="<?php echo e(old('due')); ?>"
                                        <?php endif; ?>>

                                    <?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                
                            </div>
                        </div>


                        <div class="row form-group">
                            <div class="col-md">
                                <label for=""><b>Payment Method*</b></label>
                                <select name="payment_method" class="form-control <?php $__errorArgs = ['supplierID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="" selected disabled>Select One</option>
                                    <option value="1" 
                                        <?php if(isset($record)): ?> <?php echo e(($record->payment_method == "1") ? 'selected' : ''); ?> <?php endif; ?> >
                                        Bank Payment
                                    </option>
                                    <option value="2" 
                                        <?php if(isset($record)): ?> <?php echo e(($record->payment_method == "2") ? 'selected' : ''); ?> <?php endif; ?>>Cash Payment</option>
                                    <option value="3" 
                                        <?php if(isset($record)): ?> <?php echo e(($record->payment_method == "3") ? 'selected' : ''); ?> <?php endif; ?>>Online Transaction</option>
                                </select>

                                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md">
                                <label for=""><b>Choose Image</b></label>
                                <?php if(isset($record)): ?>
                                <br>  <img src="<?php echo e(asset($record->image)); ?>" alt="image" width="200" class="img-fluid">
                                <?php endif; ?>
                                <input type="file" name="image" 
                                    class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for=""><b>Purchase note*</b></label>
                            <textarea type="text" name="note" class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            ><?php if(isset($record)): ?><?php echo e($record->note); ?><?php else: ?><?php echo e(old('note')); ?><?php endif; ?></textarea>

                            <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button class="btn btn-primary">Save</button>
                    </form>
                </div>

            </div>
        </div>
   </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

    <script>

        const loadProductUnit = (index) => {
            const key = $("#productKey-"+index).val();
            // console.log(key);
            $.ajax({
                url: '<?php echo e(route("material.unit")); ?>',
                type: 'GET',
                data:{
                    key: key
                },
                success: (res) => {
                    // console.log(res);
                    $("#loadUnitFromAjax-"+index).html(res);
                },
                error: (err) => {
                    console.log(err);
                }
            })

            $.ajax({
                url: '<?php echo e(route("material.price")); ?>',
                type: 'GET',
                data:{
                    key: key
                },
                success: (res) => {
                    console.log(res);
                    $("#unit_price-"+index).val(res);
                },
                error: (err) => {
                    console.log(err);
                }
            })
        }

        <?php if(isset($record)): ?>
        let x = <?php echo e(count(json_decode($record->data)) - 1); ?>;
        <?php else: ?>
        let x = 0;
        <?php endif; ?>
        $("#add_product_item").click(function(){
            x++;
            var html = '<div class="row" id="material-row-'+ x +'">\
                                <div class="col-md-3">\
                                    <label for="">Material Name*</label>\
                                    <select name="name[]" id="productKey-'+x+'" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="loadProductUnit('+x+')">\
                                        <option value="" selected disabled>Select One</option>\
                                        <?php $__currentLoopData = \App\Models\Material::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>\
                                        <option value="<?php echo e($item->id); ?>"\
                                            <?php if(isset($record)): ?>\
                                                <?php echo e(($record->name == $item->id)? 'selected':''); ?>\
                                            <?php else: ?><?php echo e((old('name')?'selected':'')); ?>  \
                                            <?php endif; ?>  >\
                                        <?php echo e($item->name); ?></option>\
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>\
                                    </select>\
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>\
                                        <span class="invalid-feedback">\
                                            <strong><?php echo e($message); ?></strong>\
                                        </span>\
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>\
                                </div>\
                                <div class="col-md">\
                                <label for=""><b>Quantity</b></label>\
                                <input type="text" name="quantity[]" id="quantity-'+x+'"\
                                    class="form-control"\
                                    onchange="calculator('+ x +')">\
                            </div>\
                            <div class="col-md" id="loadUnitFromAjax-'+x+'">\
                                    <label for="">Unit*</label>\
                                    <select name="unit[]" id="" class="form-control <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>\
                                        <option value="" selected disabled>Select One</option>\
                                        <?php $__currentLoopData = \App\Models\Unit::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>\
                                            <option value="<?php echo e($item->id); ?>"\
                                                <?php if(isset($record)): ?>\
                                                    <?php echo e(($record->unit_id == $item->id) ? 'selected' : ''); ?>\
                                                <?php else: ?><?php echo e((old('unit_id')== $item->id) ? 'selected' : ''); ?>\
                                                <?php endif; ?>> \
                                            <?php echo e($item->name); ?></option>\
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>\
                                    </select>\
                                    <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>\
                                        <span class="invalid-feedback">\
                                            <strong><?php echo e($message); ?></strong>\
                                        </span>\
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>\
                                </div>\
                            <div class="col-md">\
                                <label for=""><b>Unit Price</b></label>\
                                <input type="text" name="unit_price[]" id="unit_price-'+x+'"\
                                    class="form-control"\
                                    onchange="calculator('+x+')">\
                            </div>\
                            <div class="col-md">\
                                <label for=""><b>Discount(%)</b></label>\
                                <input type="text" name="discount[]" id="discount-'+x+'"\
                                    class="form-control"\
                                    onkeyup="calculator('+x+')"\>\
                            </div>\
                            <div class="col-md">\
                                <label><b>Sub Total</b></label>\
                                <input type="text" name="sub_total[]" class="form-control" id="single-total-'+x+'">\
                            </div>\
                            <div class="col-md p-2 ">\
                                <div class="btn btn-danger mt-4" id="remove_product_item" onclick="deleteRow('+x+')">\
                                    <i class="fas fa-times"></i>\
                                </div>\
                            </div>\
                        </div>';

            
            $("#product_item").append(html);
        })


        var deleteRow = (rowId) => {

            $("#product_item #material-row-"+rowId+"").remove();
            x--;
            totalCount();
        }


        var calculator = (key) => {

            let quantity = Number($('#quantity-'+key).val());
            let unit_price = Number($('#unit_price-'+key).val());
            let discount = Number($('#discount-'+key).val());

            // alert(key);

            // console.log(quantity, unit_price, discount);

            if(quantity != '' && unit_price != '')
            {
                // get total unit price
                let total_unit_price = quantity * unit_price;
                let singleTotal = total_unit_price - ((total_unit_price * discount) / 100);

                // show value
                $("#single-total-"+key).val(singleTotal.toFixed(2));

                totalCount();
                
            }
        }


        let totalCount = () => {

            let transportCost   = Number($("#transport_cost").val());
            let totalPaid       = Number($("#total_paid").val());
            let totalBill = 0;
            // alert(x);
            for(i=0; i<=x; i++)
            {
                totalBill += Number($("#single-total-"+i).val());
            }

            totalBill = totalBill + transportCost;
            let due = totalBill - totalPaid;

            $("#total_bill").val(totalBill.toFixed(2));
            $("#due").val(due.toFixed(2));

        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/supplier/materialPurchase/form.blade.php ENDPATH**/ ?>