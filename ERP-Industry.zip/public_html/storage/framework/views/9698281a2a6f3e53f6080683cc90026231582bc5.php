<?php $__env->startSection('page_title', 'Production Per Day'); ?>
            
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Production Per Days</h1>
        <a href="<?php echo e(route('ProductionPerDay.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Add New Record
        </a>
    </div>

<div class="card shadow">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover data-table" style="color:black;">
        <?php $__env->startSection('page_title', 'Production History'); ?>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Party Name</th>
                    <th>No Of Production</th>
                    <th>Production date</th>
                    <th>Remark</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $ProductionPerDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row" ><?php echo e(++$key); ?></th>
                    <td> <img src="<?php echo e(asset(\App\Models\Product::find($item->product_id)->image)); ?>" alt="" class="img-fluid rounded-circle m-auto d-block" width="50"></td>
                    <td><?php echo e(\App\Models\Product::find($item->product_id)->name); ?></td>
                    <td><?php echo e(\App\Models\Party::find($item->party_id)->name); ?></td>
                    <td><?php echo e($item->production); ?></td>
                    <td><?php echo e($item->production_date); ?></td>
                    <td><?php echo e($item->remark); ?></td>
                    <td class="text-nowrap">
                            <a href="<?php echo e(route('ProductionPerDay.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-pen"></i>
                            </a>

                            <button class="btn btn-sm btn-primary"
                                onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('/ProductionPerDay/delete/<?php echo e($item->id); ?>'); }">
                                <i class="fas fa-trash"></i>
                            </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-5 text-center">
                    <tr>
                        <td colspan='9' style="text-align: center;">No Record Found</td>
                    </tr> 
                </div>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/inventory/ProductionPerDay/table.blade.php ENDPATH**/ ?>