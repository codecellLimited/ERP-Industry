<?php $__env->startSection('page_title', 'Order List'); ?>
   
<?php $__env->startSection('web-content'); ?>

<!-- page heading  -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="mb-0 text-gray-800 "> Order List</h1>
    <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary shadow-sm">
        <i class="fas fa-plus fa-sm text-white-50"></i>
        <span>Add new Order</span>
    </a>

</div>

<!-- page contain  -->
<div class="card shadow">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover data-table" style="color:black;">
        <?php $__env->startSection('page_title', 'Client Order List'); ?>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Order ID</th>
                    <th>Company logo</th>
                    <th>Order By</th>
                    <th>Party Name</th>
                    <th>Total Bill</th>
                    <th>Total Paid</th>
                    <th>Total Due</th>
                    <th>Status</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row" ><?php echo e(++$key); ?></th>
                    <td><?php echo e($item->id); ?></td>
                    <td><img src="<?php echo e(asset(\App\Models\Party::find($item->party_id)->image)); ?>" alt="" class="img-fluid m-auto d-block" width="70"></td>
                    <td><?php echo e(\App\Models\Party::find($item->party_id)->company); ?></td>
                    
                    <td><?php echo e(Str::upper( \App\Models\Party::find($item->party_id)->name)); ?></td>
                    <td><?php echo e($item->total_price); ?></td>
                    <td><?php echo e($item->total_paid); ?></td>
                    <td><?php echo e($item->due); ?></td>
                    <td>
                        <?php if($item->status == 1): ?>
                        <span class="badge bg-warning">On Processing</span>
                        <?php elseif($item->status == 2): ?>
                        <span class="badge bg-success text-light">Completed</span>
                        <?php elseif($item->status == 3): ?>
                        <span class="badge bg-success text-light">Delivered</span>
                        <?php elseif($item->status == 0): ?>
                        <span class="badge bg-danger text-light">Rejected</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-inline-block dropdown">
                            <button type="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false" class="dropdown-toggle btn btn-sm btn-info text-nowrap">
                                Action
                            </button>
                            <div tabindex="-1" role="menu" aria-hidden="true"
                                class="dropdown-menu dropdown-menu-right">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('order.view', $item->id)); ?>">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                            <span> Invoice</span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('order.edit', $item->id)); ?>">
                                            <i class="nav-link-icon fa fa-pen"></i>
                                            <span> Edit</span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::" onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('order/delete/<?php echo e($item->id); ?>'); }">
                                            <i class="nav-link-icon fa fa-trash"></i>
                                            <span> Delete</span>
                                        </a>
                                    </li>

                                    <?php if($item->status !== 1): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('order.status', [$item->id, 1])); ?>'); }"
                                        >
                                            <i class="nav-link-icon fa fa-handshake"></i>
                                            <span>On Processing</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    
                                    <?php if($item->status !== 2): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('order.status', [$item->id, 2])); ?>'); }"
                                        >
                                            <i class="nav-link-icon fa fa-handshake"></i>
                                            <span>Completed</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($item->status !== 0): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="javascript::"
                                            onclick="if(confirm('Are you sure? you are changing the status of this record')){ location.replace('<?php echo e(route('order.status', [$item->id, 0])); ?>'); }"
                                            >
                                            <i class="nav-link-icon fa fa-ban"></i>
                                            <span>Rejected</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-5 text-center">
                    <tr>
                        <td colspan="11" style="text-align: center;">No record found</td>
                    </tr>
                </div>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/party/order/table.blade.php ENDPATH**/ ?>