<?php $__env->startSection('page_title', 'Employee Salary'); ?>
   
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Employee Salary List</h1>
        
    </div>


    <div class="row " style="color:black;">
        <div class="col-md-6">
            <div class="card shadow">

                <div class="card-body">

                    <div class="form-group">
                        <form action="<?php echo e(route('salary')); ?>" method="GET" id="orderIdForm">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md">
                                        <label for=""><b>Search on month</b></label>
                                        <select name="searchmonth" class="form-control <?php $__errorArgs = ['searchmonth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="0" selected>select a month</option>
                                            <option value="1" >Januart</option>
                                            <option value="2" >February</option>
                                            <option value="3" >March</option>
                                            <option value="4" >April</option>
                                            <option value="5" >May</option>
                                            <option value="6" >June</option>
                                            <option value="7" >July</option>
                                            <option value="8" >August</option>
                                            <option value="9" >September</option>
                                            <option value="10" >October</option>
                                            <option value="11" >November</option>
                                            <option value="12" >December</option>
                                        </select>

                                        <?php $__errorArgs = ['searchmonth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                    </div>
                                    
                                    <div class="col">
                                        <label for="search">  </label><br>
                                        <button class="btn btn-primary">Search</button>
                                    </div>

                                    
                                </div>
                            </div>
                                
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
   </div>
   <br><br>
    

<div class="card shadow">
    <div class="card-body table-responsive">

        <div class="d-sm-flex align-items-center justify-content-between mb-4" >
            <h1 class="h3 mb-0 text-gray-800" style="color:black;" ><b> Employee Salary List
                </b></h1>
            
        </div>

        <table class="table table-striped table-hover table-bordered data-table" style="color:black;">
        <?php $__env->startSection('page_title', 'Employee Salary'); ?>    
        <thead>
                <tr>
                    
                    <th width="10%">ID</th>
                    <th width="30%">Employee Name</th>
                    <th width="10%">Department</th>
                    <th width="10%">Salary</th>
                    
                </tr>

            </thead>


            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $salarys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->id_no); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e(\App\Models\Department:: find($item->department_id)->name); ?></td>
                    <td><?php echo e($item->monthly_salary); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-4 text-center">
                    <tr>
                        <td colspan='4' style="text-align: center;">No Record Found</td>
                    </tr> 
                </div>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/HR/salary/table.blade.php ENDPATH**/ ?>