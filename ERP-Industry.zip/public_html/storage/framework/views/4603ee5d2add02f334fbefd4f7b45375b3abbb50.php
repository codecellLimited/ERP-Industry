<?php $__env->startSection('page_title', 'Quotations'); ?>
   
<?php $__env->startSection('web-content'); ?>

<!-- page heading  -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="mb-0 text-gray-800 "> Quotation List</h1>
    <a href="<?php echo e(route('quotation.create')); ?>" class="btn btn-primary shadow-sm">
        <i class="fas fa-plus fa-sm text-white-50"></i>
        <span>Add new Record</span>
    </a>

</div>

<!-- page contain  -->
<div class="card shadow">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover" style="color:black;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Party Name</th>
                    <th>Total Bill</th>
                    <!-- <th>Status</th> -->
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $quotation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row" ><?php echo e(++$key); ?></th>
                    <th><?php echo e($item->quotation_date); ?></th>
                    <td><?php echo e(Str::upper( \App\Models\Party::find($item->party_id)->name)); ?></td>
                    <td><?php echo e($item->total_price); ?></td>
                    <!-- <td><?php if($item->quotation_status == 1): ?> <span class="badge bg-warning">Sending</span>
                        <?php elseif($item->quotation_status == 2): ?> <span class="badge bg-primary">Pending</span>
                        <?php endif; ?>
                    </td> -->
                    <td class="text-nowrap">
                            <a href="<?php echo e(route('quotation.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-pen"></i>
                            </a>

                            <button class="btn btn-sm btn-primary"
                                onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('quotation/delete/<?php echo e($item->id); ?>'); }">
                                <i class="fas fa-trash"></i>
                            </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-5 text-center">
                    <tr>
                        <td colspan="5" style="text-align: center;">No record found</td>
                    </tr>
                </div>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/sales/quotation/table.blade.php ENDPATH**/ ?>