<?php $__env->startSection('page_title', 'Products'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Products</h1>
        <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Add New Record
        </a>
    </div>

<div class="card shadow">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover" style="color:black;">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Catagory</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Unit</th>
                    <th>Description</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row" ><?php echo e(++$key); ?></th>
                    <td><img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid rounded-circle m-auto d-block" width="50"></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e(\App\Models\Catagory::find($item->catagory_id)->name); ?></td>
                    <td><?php echo e(App\Models\Brand::find($item->brand_id)->name); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e(\App\Models\Unit:: find($item->unit_id)->name); ?></td>
                    <td><?php echo e($item->description); ?></td>
                    <td>
                            <a href="<?php echo e(route('product.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-pen"></i>
                            </a>

                            <button class="btn btn-sm btn-primary"
                                onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('product/delete/<?php echo e($item->id); ?>'); }">
                                <i class="fas fa-trash"></i>
                            </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 py-5 text-center">
                    <tr>
                        <td colspan='9' style="text-align: center;">No Record Found</td>
                    </tr> 
                </div>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/sales/product/table.blade.php ENDPATH**/ ?>