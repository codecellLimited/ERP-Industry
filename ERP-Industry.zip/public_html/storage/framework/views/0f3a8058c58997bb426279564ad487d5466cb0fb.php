<?php $__env->startSection('page_title', 'Assets'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Assets Of The Company</h1>
        <a href="<?php echo e(route('asset.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Create New Record
        </a>
    </div>

    <div class="card shadow col-md-8">
        <div class="card-body table-responsive">
            <table class="table table-striped table-hover data-table" style="color:black;">
            <?php $__env->startSection('page_title', 'Company Asset list'); ?>
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Asset Name</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Quality</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $asset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row" ><?php echo e(++$key); ?></th>
                        <td><img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid m-auto d-block" width="50"></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->quality); ?></td>
                        <td>
                            <a href="<?php echo e(route('asset.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-pen"></i>
                            </a>

                            <button class="btn btn-sm btn-primary"
                                onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('asset/delete/<?php echo e($item->id); ?>'); }">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 py-5 text-center">
                        <tr>
                            <td colspan='5' style="text-align: center;">No Record Found</td>
                        </tr> 
                    </div>
                    <?php endif; ?>
                    
                </tbody>
            </table>
        </div>
    </div>

    








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/inventory/asset/table.blade.php ENDPATH**/ ?>