<?php $__env->startSection('page_title', 'transections'); ?>
   
<?php $__env->startSection('web-content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Transections History</h1>
        <a href="<?php echo e(route('transection.create')); ?>" class="btn btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Add new transection
        </a>
    </div>

    <div class="card shadow">
        <div class="card-body  table-responsive">
            <table class="table table-striped table-hover data-table" style="color:black;">
            <?php $__env->startSection('page_title', 'transection list'); ?>
                <thead>
                    <tr style="color:black;">
                        <th scope="col">#</th>
                        <th scope="col">Date</th>
                        <th scope="col">Transection Purpose</th>
                        <th scope="col">Payment Method</th>
                        <th scope="col">Account No</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Remark</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="color:black;">
                        <th scope="row" ><?php echo e(++$key); ?></th>
                        <td><?php echo e(date('d-m-Y',strtotime($item->date))); ?></td>
                        <td> <?php if($item->purpose == 1): ?> Party Receive
                            <?php elseif($item->purpose == 2): ?> Supplier Payment
                            <?php else: ?>
                            <?php endif; ?>
                        </td>
                        <td><?php if( $item->payment_method == 1): ?> Hand Cash
                            <?php elseif( $item->payment_method == 2): ?> Bank Transection 
                            <?php else: ?> 
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(\App\Models\Bankadd::find($item->account)->account_number ?? "Hand Cash"); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e($item->remark); ?></td>
                        <td class="text-nowrap">
                             <a href="<?php echo e(route('transection.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-pen"></i>
                            </a>

                            <button class="btn btn-sm btn-primary"
                                onclick="if(confirm('Are you sure? you are going to delete this record')){ location.replace('transection/delete/<?php echo e($item->id); ?>'); }">
                                <i class="fas fa-trash"></i>
                            </button> 
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 py-5 text-center">
                        <tr>
                            <td colspan="8" style="text-align: center;">No record found</td>
                        </tr>
                    </div>
                    <?php endif; ?>
                    
                </tbody>
            </table>
        </div>
    </div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moonskynl.com/public_html/resources/views/account/bankcash/transection/table.blade.php ENDPATH**/ ?>